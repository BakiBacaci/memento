/// Bir kullanıcı profili.
///
/// Sayaçlar (karma, sözler, takipçiler) kullanıcı dökümanında tutuluyor.
/// Alternatifi her profil açılışında sayım sorgusu atmaktı; bu şekilde
/// profil tek okumayla açılıyor.
class AppUser {
  final String uid;
  final String username;
  final String bio;
  final String? photoUrl;
  final int karma;
  final int quoteCount;
  final int followerCount;
  final int followingCount;

  const AppUser({
    required this.uid,
    required this.username,
    this.bio = '',
    this.photoUrl,
    this.karma = 0,
    this.quoteCount = 0,
    this.followerCount = 0,
    this.followingCount = 0,
  });

  bool get hasPhoto => photoUrl != null && photoUrl!.isNotEmpty;

  /// Fotoğrafı olmayanlar için baş harf.
  String get initial =>
      username.isNotEmpty ? username.substring(0, 1).toUpperCase() : 'M';

  factory AppUser.fromMap(String uid, Map<String, dynamic>? d) {
    d ??= const {};
    return AppUser(
      uid: uid,
      username: (d['username'] as String?) ?? 'Anonim',
      bio: (d['bio'] as String?) ?? '',
      photoUrl: d['photo_url'] as String?,
      karma: (d['karma'] as num?)?.toInt() ?? 0,
      quoteCount: (d['quote_count'] as num?)?.toInt() ?? 0,
      followerCount: (d['follower_count'] as num?)?.toInt() ?? 0,
      followingCount: (d['following_count'] as num?)?.toInt() ?? 0,
    );
  }
}
