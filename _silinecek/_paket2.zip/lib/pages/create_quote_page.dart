import 'package:flutter/material.dart';

import '../l10n/strings.dart';
import '../models/app_user.dart';
import '../models/quote.dart';
import '../services/quote_service.dart';
import '../services/settings_service.dart';
import '../services/user_service.dart';
import '../theme.dart';
import '../widgets/common.dart';

class CreateQuotePage extends StatefulWidget {
  const CreateQuotePage({super.key, this.onRequireSignIn});
  final VoidCallback? onRequireSignIn;

  @override
  State<CreateQuotePage> createState() => _CreateQuotePageState();
}

class _CreateQuotePageState extends State<CreateQuotePage> {
  static const _maxLength = 280;

  final _text = TextEditingController();
  final _author = TextEditingController();

  String _visibility = QuoteVisibility.public;
  String _quoteLang = 'tr';
  bool _sending = false;
  AppUser? _me;

  @override
  void initState() {
    super.initState();
    _quoteLang = SettingsService.instance.language.value;
    _loadMe();
  }

  @override
  void dispose() {
    _text.dispose();
    _author.dispose();
    super.dispose();
  }

  Future<void> _loadMe() async {
    final uid = UserService.instance.uid;
    if (uid == null) return;
    final me = await UserService.instance.get(uid);
    if (!mounted || me == null) return;
    setState(() {
      _me = me;
      if (_author.text.isEmpty) _author.text = me.username;
    });
  }

  Future<void> _submit() async {
    if (!UserService.instance.isSignedIn) {
      final wants = await requireSignIn(context);
      if (wants) widget.onRequireSignIn?.call();
      return;
    }

    final text = _text.text.trim();
    if (text.isEmpty) return;

    setState(() => _sending = true);
    try {
      await QuoteService.instance.createQuote(
        text: text,
        author: _author.text,
        visibility: _visibility,
        lang: _quoteLang,
        ownerUsername: _me?.username,
        ownerPhotoUrl: _me?.photoUrl,
      );
      if (!mounted) return;
      _text.clear();
      FocusScope.of(context).unfocus();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(context.t('published')),
          backgroundColor: AppColors.gold,
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('${context.t('publish_failed')}: $e'),
        backgroundColor: Colors.red,
      ));
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 12),
              Center(
                child: Text(
                  context.t('share_wisdom'),
                  style: const TextStyle(
                    color: AppColors.gold,
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2,
                  ),
                ),
              ),
              const SizedBox(height: 24),
              TextField(
                controller: _text,
                maxLines: 5,
                maxLength: _maxLength,
                style: const TextStyle(color: Colors.white, fontFamily: kSerif),
                decoration:
                    InputDecoration(hintText: context.t('quote_hint')),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: _author,
                style: const TextStyle(color: Colors.white),
                decoration:
                    InputDecoration(hintText: context.t('author_hint')),
              ),
              const SizedBox(height: 20),

              _Label(context.t('quote_language')),
              const SizedBox(height: 6),
              SegmentedButton<String>(
                segments: [
                  for (final code in L.supported)
                    ButtonSegment(value: code, label: Text(L.languageName(code))),
                ],
                selected: {_quoteLang},
                onSelectionChanged: (s) =>
                    setState(() => _quoteLang = s.first),
                style: SegmentedButton.styleFrom(
                  foregroundColor: Colors.grey,
                  selectedForegroundColor: Colors.black,
                  selectedBackgroundColor: AppColors.gold,
                ),
              ),

              const SizedBox(height: 20),
              _Label(context.t('vis_public')),
              const SizedBox(height: 6),
              for (final v in QuoteVisibility.all)
                RadioListTile<String>(
                  value: v,
                  groupValue: _visibility,
                  onChanged: (x) => setState(() => _visibility = x!),
                  activeColor: AppColors.gold,
                  contentPadding: EdgeInsets.zero,
                  dense: true,
                  title: Text(
                    context.t(QuoteVisibility.labelKey(v)),
                    style: const TextStyle(color: Colors.white, fontSize: 14),
                  ),
                ),

              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: _sending ? null : _submit,
                child: _sending
                    ? const SizedBox(
                        height: 20,
                        width: 20,
                        child: CircularProgressIndicator(
                            color: Colors.black, strokeWidth: 2),
                      )
                    : Text(context.t('publish')),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Label extends StatelessWidget {
  const _Label(this.text);
  final String text;

  @override
  Widget build(BuildContext context) => Text(
        text.toUpperCase(),
        style: const TextStyle(
          color: Colors.grey,
          fontSize: 11,
          fontWeight: FontWeight.bold,
          letterSpacing: 1.2,
        ),
      );
}
