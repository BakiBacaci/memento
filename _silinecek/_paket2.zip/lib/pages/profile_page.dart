import 'package:flutter/material.dart';

import '../l10n/strings.dart';
import '../models/app_user.dart';
import '../models/quote.dart';
import '../services/follow_service.dart';
import '../services/quote_service.dart';
import '../services/saved_service.dart';
import '../services/user_service.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../widgets/quote_actions.dart';
import '../widgets/quote_tile.dart';
import '../widgets/share_card.dart';
import '../widgets/user_avatar.dart';
import 'edit_profile_page.dart';
import 'settings_page.dart';

/// Tek bir profil sayfası hem kendi profilin hem başkasınınki için çalışıyor.
/// `uid` verilmezse giriş yapmış kullanıcının profili açılır.
class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key, this.uid, this.onRequireSignIn});

  final String? uid;
  final VoidCallback? onRequireSignIn;

  @override
  Widget build(BuildContext context) {
    final myUid = UserService.instance.uid;
    final targetUid = uid ?? myUid;

    if (targetUid == null) {
      return Scaffold(
        appBar: AppBar(title: Text(context.t('profile'))),
        body: EmptyState(
          message: context.t('sign_in_required'),
          icon: Icons.lock_outline,
          action: OutlinedButton(
            onPressed: onRequireSignIn,
            child: Text(context.t('sign_in_to_continue')),
          ),
        ),
      );
    }

    final isMe = targetUid == myUid;

    return StreamBuilder<AppUser>(
      stream: UserService.instance.watch(targetUid),
      builder: (context, snap) {
        if (snap.hasError) {
          return Scaffold(
            appBar: AppBar(title: Text(context.t('profile'))),
            body: EmptyState(
              message: context.t('profile_load_failed'),
              icon: Icons.cloud_off,
            ),
          );
        }
        final user = snap.data;

        return DefaultTabController(
          length: isMe ? 2 : 1,
          child: Scaffold(
            appBar: AppBar(
              title: Text(user?.username ?? context.t('profile')),
              leading: isMe && uid == null ? null : const BackButton(),
              actions: [
                if (isMe)
                  IconButton(
                    icon: const Icon(Icons.settings_outlined),
                    onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const SettingsPage()),
                    ),
                  ),
              ],
            ),
            body: Column(
              children: [
                _Header(user: user, isMe: isMe, targetUid: targetUid),
                TabBar(
                  tabs: [
                    Tab(text: context.t('my_quotes')),
                    if (isMe) Tab(text: context.t('my_saved')),
                  ],
                ),
                Expanded(
                  child: TabBarView(
                    children: [
                      _UserQuotes(uid: targetUid, isMe: isMe),
                      if (isMe) const _SavedQuotes(),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _Header extends StatelessWidget {
  const _Header({required this.user, required this.isMe, required this.targetUid});

  final AppUser? user;
  final bool isMe;
  final String targetUid;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 16),
      child: Column(
        children: [
          UserAvatar(
            photoUrl: user?.photoUrl,
            initial: user?.username,
            radius: 42,
          ),
          const SizedBox(height: 12),
          Text(
            user?.username ?? '...',
            style: const TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          if ((user?.bio ?? '').isNotEmpty) ...[
            const SizedBox(height: 6),
            Text(
              user!.bio,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.grey, fontSize: 13),
            ),
          ],
          const SizedBox(height: 18),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _Stat(value: user?.karma ?? 0, labelKey: 'karma'),
              _Stat(value: user?.quoteCount ?? 0, labelKey: 'quotes_count'),
              _Stat(value: user?.followerCount ?? 0, labelKey: 'followers'),
              _Stat(value: user?.followingCount ?? 0, labelKey: 'following'),
            ],
          ),
          const SizedBox(height: 16),
          if (isMe)
            OutlinedButton(
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => EditProfilePage(user: user)),
              ),
              child: Text(context.t('edit_profile')),
            )
          else
            _FollowButton(targetUid: targetUid),
        ],
      ),
    );
  }
}

class _Stat extends StatelessWidget {
  const _Stat({required this.value, required this.labelKey});
  final int value;
  final String labelKey;

  @override
  Widget build(BuildContext context) => Column(
        children: [
          // Sayı değişince yumuşak geçiş — karma arttığında fark edilir.
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 300),
            transitionBuilder: (child, anim) =>
                ScaleTransition(scale: anim, child: child),
            child: Text(
              '$value',
              key: ValueKey('$labelKey$value'),
              style: const TextStyle(
                color: AppColors.gold,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          const SizedBox(height: 2),
          Text(context.t(labelKey),
              style: const TextStyle(color: Colors.grey, fontSize: 11)),
        ],
      );
}

class _FollowButton extends StatefulWidget {
  const _FollowButton({required this.targetUid});
  final String targetUid;

  @override
  State<_FollowButton> createState() => _FollowButtonState();
}

class _FollowButtonState extends State<_FollowButton> {
  bool _busy = false;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<bool>(
      stream: FollowService.instance.isFollowing(widget.targetUid),
      builder: (context, snap) {
        final following = snap.data ?? false;
        return SizedBox(
          width: 180,
          child: following
              ? OutlinedButton(
                  onPressed: _busy ? null : () => _toggle(true),
                  child: Text(context.t('unfollow')),
                )
              : ElevatedButton(
                  onPressed: _busy ? null : () => _toggle(false),
                  style: ElevatedButton.styleFrom(
                    minimumSize: const Size(0, 40),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20)),
                  ),
                  child: Text(context.t('follow')),
                ),
        );
      },
    );
  }

  Future<void> _toggle(bool currentlyFollowing) async {
    if (!UserService.instance.isSignedIn) {
      await requireSignIn(context);
      return;
    }
    setState(() => _busy = true);
    try {
      await FollowService.instance.toggle(widget.targetUid, currentlyFollowing);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }
}

class _UserQuotes extends StatelessWidget {
  const _UserQuotes({required this.uid, required this.isMe});
  final String uid;
  final bool isMe;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<Quote>>(
      stream: QuoteService.instance.byUser(uid),
      builder: (context, snap) {
        if (snap.hasError) {
          return EmptyState(
              message: context.t('load_failed'), icon: Icons.cloud_off);
        }
        if (!snap.hasData) return const ShimmerList(count: 3);
        final quotes = snap.data!;
        if (quotes.isEmpty) {
          return EmptyState(
            message: context.t(isMe ? 'no_quotes_yet' : 'user_no_quotes'),
            icon: Icons.format_quote,
          );
        }
        return ListView.builder(
          padding: const EdgeInsets.symmetric(vertical: 8),
          itemCount: quotes.length,
          itemBuilder: (context, i) => QuoteTile(
            quote: quotes[i],
            onShareTap: () => QuoteShareSheet.show(context, quotes[i]),
            onMoreTap: () => QuoteActions.show(context, quotes[i]),
          ),
        );
      },
    );
  }
}

class _SavedQuotes extends StatelessWidget {
  const _SavedQuotes();

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<Quote>>(
      stream: SavedService.instance.watch(),
      builder: (context, snap) {
        if (snap.hasError) {
          return EmptyState(
              message: context.t('load_failed'), icon: Icons.cloud_off);
        }
        if (!snap.hasData) return const ShimmerList(count: 3);
        final quotes = snap.data!;
        if (quotes.isEmpty) {
          return EmptyState(
            message: context.t('no_saved_yet'),
            icon: Icons.bookmark_border,
          );
        }
        return ListView.builder(
          padding: const EdgeInsets.symmetric(vertical: 8),
          itemCount: quotes.length,
          itemBuilder: (context, i) => QuoteTile(
            quote: quotes[i],
            onShareTap: () => QuoteShareSheet.show(context, quotes[i]),
            trailing: IconButton(
              icon: const Icon(Icons.bookmark, color: AppColors.gold, size: 18),
              onPressed: () => SavedService.instance.toggle(quotes[i]),
            ),
          ),
        );
      },
    );
  }
}
