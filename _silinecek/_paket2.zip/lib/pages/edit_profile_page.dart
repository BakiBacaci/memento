import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../l10n/strings.dart';
import '../models/app_user.dart';
import '../services/storage_service.dart';
import '../services/user_service.dart';
import '../theme.dart';
import '../widgets/user_avatar.dart';

class EditProfilePage extends StatefulWidget {
  const EditProfilePage({super.key, required this.user});
  final AppUser? user;

  @override
  State<EditProfilePage> createState() => _EditProfilePageState();
}

class _EditProfilePageState extends State<EditProfilePage> {
  late final _name = TextEditingController(text: widget.user?.username ?? '');
  late final _bio = TextEditingController(text: widget.user?.bio ?? '');

  String? _photoUrl;
  bool _saving = false;
  bool _uploading = false;

  @override
  void initState() {
    super.initState();
    _photoUrl = widget.user?.photoUrl;
  }

  @override
  void dispose() {
    _name.dispose();
    _bio.dispose();
    super.dispose();
  }

  Future<void> _pickPhoto() async {
    final uid = UserService.instance.uid;
    if (uid == null) return;

    final XFile? file = await StorageService.instance.pickImage();
    if (file == null) return;

    setState(() => _uploading = true);
    final url = await StorageService.instance.uploadProfilePhoto(uid, file);
    if (!mounted) return;

    if (url == null) {
      setState(() => _uploading = false);
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(context.t('photo_failed'))));
      return;
    }

    await UserService.instance.updatePhotoUrl(uid, url);
    if (!mounted) return;
    setState(() {
      _photoUrl = url;
      _uploading = false;
    });
  }

  Future<void> _save() async {
    final uid = UserService.instance.uid;
    final username = _name.text.trim();
    if (uid == null) return;

    if (!UserService.isValidUsername(username)) {
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(context.t('err_username_invalid'))));
      return;
    }

    setState(() => _saving = true);
    try {
      final changed = username.toLowerCase() !=
          (widget.user?.username ?? '').toLowerCase();
      if (changed && !await UserService.instance.isUsernameAvailable(username)) {
        if (!mounted) return;
        setState(() => _saving = false);
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(context.t('err_username_taken'))));
        return;
      }

      await UserService.instance.updateProfile(
        uid: uid,
        username: username,
        bio: _bio.text.trim(),
        previousUsername: widget.user?.username,
      );
      await UserService.instance.currentUser?.updateDisplayName(username);

      if (!mounted) return;
      Navigator.pop(context);
    } on UsernameTakenException {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(context.t('err_username_taken'))));
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('${context.t('err_generic')} $e')));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(context.t('edit_profile'))),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            Stack(
              alignment: Alignment.bottomRight,
              children: [
                UserAvatar(
                  photoUrl: _photoUrl,
                  initial: _name.text,
                  radius: 50,
                  onTap: _uploading ? null : _pickPhoto,
                ),
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: const BoxDecoration(
                    color: AppColors.gold,
                    shape: BoxShape.circle,
                  ),
                  child: _uploading
                      ? const SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(
                              strokeWidth: 2, color: Colors.black),
                        )
                      : const Icon(Icons.camera_alt,
                          size: 16, color: Colors.black),
                ),
              ],
            ),
            const SizedBox(height: 8),
            TextButton(
              onPressed: _uploading ? null : _pickPhoto,
              child: Text(context.t('change_photo')),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _name,
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(labelText: context.t('username')),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _bio,
              maxLines: 3,
              maxLength: 160,
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(labelText: context.t('bio')),
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: _saving ? null : _save,
              child: _saving
                  ? const SizedBox(
                      height: 20,
                      width: 20,
                      child: CircularProgressIndicator(
                          color: Colors.black, strokeWidth: 2),
                    )
                  : Text(context.t('save')),
            ),
          ],
        ),
      ),
    );
  }
}
