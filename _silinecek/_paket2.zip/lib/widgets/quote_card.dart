import 'package:flutter/material.dart';

import '../l10n/strings.dart';
import '../models/quote.dart';
import '../theme.dart';
import 'user_avatar.dart';

/// Keşfet destesindeki kart.
///
/// Kaydırma yönüne göre üstünde yeşil "BEĞEN" / kırmızı "GEÇ" katmanı
/// beliriyor — kullanıcı parmağını bırakmadan ne olacağını görüyor.
class QuoteCard extends StatelessWidget {
  const QuoteCard({
    super.key,
    required this.quote,
    required this.isLiked,
    required this.isSaved,
    required this.onSaveTap,
    this.onAuthorTap,
    this.onDoubleTap,
    this.onShareTap,
    this.onMoreTap,
    this.horizontalOffset = 0,
  });

  final Quote quote;
  final bool isLiked;
  final bool isSaved;
  final VoidCallback onSaveTap;
  final VoidCallback? onAuthorTap;
  final VoidCallback? onDoubleTap;
  final VoidCallback? onShareTap;
  final VoidCallback? onMoreTap;

  /// CardSwiper'dan gelen -100..100 arası kaydırma yüzdesi.
  final int horizontalOffset;

  @override
  Widget build(BuildContext context) {
    final lang = context.lang;
    final progress = (horizontalOffset.abs() / 60).clamp(0.0, 1.0);
    final goingRight = horizontalOffset > 0;

    return GestureDetector(
      onDoubleTap: onDoubleTap,
      child: Container(
        decoration: BoxDecoration(
          color: AppColors.bg,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(
            color: horizontalOffset == 0
                ? AppColors.border
                : Color.lerp(
                    AppColors.border,
                    goingRight ? AppColors.like : AppColors.pass,
                    progress,
                  )!,
            width: 1 + progress,
          ),
        ),
        clipBehavior: Clip.antiAlias,
        child: Stack(
          fit: StackFit.expand,
          children: [
            _buildContent(context, lang),
            if (progress > 0.05) _buildSwipeOverlay(context, goingRight, progress),
          ],
        ),
      ),
    );
  }

  Widget _buildContent(BuildContext context, String lang) {
    return Column(
      children: [
        // --- Üst şerit: yazar ---
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 16, 8, 0),
          child: Row(
            children: [
              UserAvatar(
                photoUrl: quote.ownerPhotoUrl,
                initial: quote.authorFor(lang),
                radius: 18,
                onTap: onAuthorTap,
              ),
              const SizedBox(width: 10),
              Expanded(
                child: GestureDetector(
                  onTap: onAuthorTap,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        quote.authorFor(lang),
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                      ),
                      if (quote.ownerUsername != null)
                        Text(
                          '@${quote.ownerUsername}',
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                              color: Colors.grey, fontSize: 11),
                        ),
                    ],
                  ),
                ),
              ),
              if (onMoreTap != null)
                IconButton(
                  icon: const Icon(Icons.more_horiz, color: Colors.white54),
                  onPressed: onMoreTap,
                ),
            ],
          ),
        ),

        // --- Söz ---
        Expanded(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 12),
            child: Center(
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    AnimatedScale(
                      scale: isLiked ? 1 : 0,
                      duration: const Duration(milliseconds: 260),
                      curve: Curves.elasticOut,
                      child: const Padding(
                        padding: EdgeInsets.only(bottom: 16),
                        child: Icon(Icons.favorite,
                            color: AppColors.like, size: 52),
                      ),
                    ),
                    Text(
                      '“${quote.textFor(lang)}”',
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        fontFamily: kSerif,
                        color: AppColors.textPrimary,
                        fontSize: 23,
                        fontStyle: FontStyle.italic,
                        height: 1.45,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),

        // --- Alt şerit: beğeni, paylaş, kaydet ---
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
          child: Row(
            children: [
              const Icon(Icons.favorite, size: 15, color: Colors.grey),
              const SizedBox(width: 5),
              Text(
                '${quote.likes}',
                style: const TextStyle(color: Colors.grey, fontSize: 13),
              ),
              const Spacer(),
              if (onShareTap != null)
                IconButton(
                  tooltip: context.t('share'),
                  icon: const Icon(Icons.ios_share,
                      color: Colors.white54, size: 24),
                  onPressed: onShareTap,
                ),
              IconButton(
                tooltip: context.t('saved'),
                icon: Icon(
                  isSaved ? Icons.bookmark : Icons.bookmark_border,
                  color: isSaved ? AppColors.gold : Colors.white54,
                  size: 26,
                ),
                onPressed: onSaveTap,
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildSwipeOverlay(
      BuildContext context, bool goingRight, double progress) {
    final color = goingRight ? AppColors.like : AppColors.pass;
    return IgnorePointer(
      child: Container(
        color: color.withValues(alpha: 0.16 * progress),
        alignment: goingRight ? Alignment.topLeft : Alignment.topRight,
        padding: const EdgeInsets.all(28),
        child: Opacity(
          opacity: progress,
          child: Transform.rotate(
            angle: goingRight ? -0.3 : 0.3,
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              decoration: BoxDecoration(
                border: Border.all(color: color, width: 3),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Text(
                goingRight ? context.t('like') : context.t('pass'),
                style: TextStyle(
                  color: color,
                  fontSize: 26,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 2,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
